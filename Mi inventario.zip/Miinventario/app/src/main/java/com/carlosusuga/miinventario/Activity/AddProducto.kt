package com.carlosusuga.miinventario.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.Toolbar
import com.carlosusuga.miinventario.R
import com.google.android.material.appbar.MaterialToolbar

class AddProducto : AppCompatActivity() {

    companion object{
        const val EXTRA_ID = "com.carlosusuga.miinventario.Activity.EXTRA_ID"
        const val EXTRA_NAME_PRODUCTO = "com.carlosusuga.miinventario.Activity.EXTRA_NAME_PRODUCTO"
        const val EXTRA_PRECIO = "com.carlosusuga.miinventario.Activity.EXTRA_PRECIO"
        const val EXTRA_DESCUENTO = "com.carlosusuga.miinventario.Activity.EXTRA_DESCUENTO"
        const val EXTRA_CATEGORIA = "com.carlosusuga.miinventario.Activity.EXTRA_CATEGORIA"
        const val EXTRA_RATING = "com.carlosusuga.miinventario.Activity.EXTRA_RATING"
        const val EXTRA_STOCK = "com.carlosusuga.miinventario.Activity.EXTRA_STOCK"
        const val EXTRA_MARCA = "com.carlosusuga.miinventario.Activity.EXTRA_MARCA"
    }

    private var editNombreProducto: EditText? = null
    private var editPrecio: EditText? = null
    private var editDescuento: EditText? = null
    private var editCategoria: EditText? = null
    private var editRating: EditText? = null
    private var editStock: EditText? = null
    private var editMarca: EditText? = null

    private var btnGuardarProducto: Button? = null

    var toolbar: MaterialToolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_producto)

        toolbar = findViewById(R.id.toolbar)
        toolbar?.setTitle(R.string.app_name)
        setSupportActionBar(toolbar)

        editNombreProducto = findViewById(R.id.edtNameProduct)
        editPrecio = findViewById(R.id.edtPrecio)
        editDescuento = findViewById(R.id.edtDescuento)
        editCategoria = findViewById(R.id.edtCategoria)
        editRating = findViewById(R.id.edtRating)
        editStock = findViewById(R.id.edtNumberStock)
        editMarca = findViewById(R.id.edtMarcaProducto)

        supportActionBar!!.setHomeAsUpIndicator(R.drawable.backspace_reverse_outline)

        val intent = intent
        if (intent.hasExtra(EXTRA_ID)){
            title = "Editar Producto"
            editNombreProducto?.setText(intent.getStringExtra(EXTRA_NAME_PRODUCTO))
            editPrecio?.setText(intent.getIntExtra(EXTRA_PRECIO, 0))
            editDescuento?.setText(intent.getIntExtra(EXTRA_DESCUENTO, 0))
            editCategoria?.setText(intent.getStringExtra(EXTRA_CATEGORIA))
            editRating?.setText(intent.getIntExtra(EXTRA_RATING, 0))
            editStock?.setText(intent.getIntExtra(EXTRA_STOCK, 0))
            editMarca?.setText(intent.getStringExtra(EXTRA_MARCA))
        } else {
            title = "Agregar Producto"
        }

        btnGuardarProducto = findViewById(R.id.btnAddProduct)
        btnGuardarProducto?.setOnClickListener {
            saveProduct()
            Intent(this, MainActivity::class.java)
            finish()
        }
    }

    private fun saveProduct(){

        val nombreProducto = editNombreProducto!!.text.toString()
        val precio = editPrecio!!.text.toString()
        val descuento = editDescuento!!.text.toString()
        val categoria = editCategoria!!.text.toString()
        val rating = editRating!!.text.toString()
        val stock = editStock!!.text.toString()
        val marca = editMarca!!.text.toString()

        if (nombreProducto.trim().isEmpty() || descuento.trim().isEmpty() || categoria.trim().isEmpty() || rating.trim().isEmpty() || stock.trim().isEmpty() || marca.trim().isEmpty()){

            Toast.makeText(this, "Ingrese toda la información", Toast.LENGTH_LONG).show()
            return
        } else {

            val data = Intent()
            data.putExtra(EXTRA_NAME_PRODUCTO, nombreProducto)
            data.putExtra(EXTRA_PRECIO, precio)
            data.putExtra(EXTRA_DESCUENTO, descuento)
            data.putExtra(EXTRA_CATEGORIA, categoria)
            data.putExtra(EXTRA_RATING, rating)
            data.putExtra(EXTRA_STOCK, stock)
            data.putExtra(EXTRA_MARCA, marca)

            val id = intent.getIntExtra(EXTRA_ID, -1)
            if (id != -1) {
                data.putExtra(EXTRA_ID, id)
            }

            setResult(RESULT_OK, data)
            finish()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val menuInflater = menuInflater
        menuInflater.inflate(R.menu.menu_back, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            R.id.itemBack -> {
                intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
}