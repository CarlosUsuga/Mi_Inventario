package com.carlosusuga.miinventario.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.carlosusuga.miinventario.Entities.ProductoEntity
import com.carlosusuga.miinventario.Repository.ProductoRepository

//@HiltViewModel
class ProductoViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProductoRepository

    val allProductos: LiveData<List<ProductoEntity>>

    init {
        repository = ProductoRepository(application)
        allProductos = repository.allProducts
    }

    fun insertProducto(productoEntity: ProductoEntity){
        repository.insertProducto(productoEntity)
    }

    fun updateProducto(productoEntity: ProductoEntity){
        repository.updateProducto(productoEntity)
    }

    fun deteleProducto(productoEntity: ProductoEntity){
        repository.deleteProducto(productoEntity)
    }
}