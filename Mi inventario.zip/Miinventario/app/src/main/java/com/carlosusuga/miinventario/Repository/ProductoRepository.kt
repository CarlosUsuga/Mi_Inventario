package com.carlosusuga.miinventario.Repository

import android.app.Application
import android.os.AsyncTask
import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData
import com.carlosusuga.miinventario.DaosInterface.ProductosDaos
import com.carlosusuga.miinventario.DataBase.MiInventarioDataBase.Companion.getInstance
import com.carlosusuga.miinventario.Entities.ProductoEntity
import kotlinx.coroutines.CoroutineScope

class ProductoRepository(application: Application) {

    private val productosDaos: ProductosDaos

    val allProducts: LiveData<List<ProductoEntity>>

    init {
        val database = getInstance(application)
        productosDaos = database!!.productosDaos()
        allProducts = productosDaos.allProductos()
    }

    fun insertProducto(productoEntity: ProductoEntity){
        InsertProductoAsyncTask(productosDaos).execute(productoEntity)
    }

    fun updateProducto(productoEntity: ProductoEntity){
        UpdateProductoAsyncTask(productosDaos).execute(productoEntity)
    }

    fun deleteProducto(productoEntity: ProductoEntity){
        DeleteProductoAsyncTask(productosDaos).execute(productoEntity)
    }

    private class InsertProductoAsyncTask(private val productosDaos: ProductosDaos) :
        AsyncTask<ProductoEntity, Void?, Void?>() {

        override fun doInBackground(vararg productos: ProductoEntity): Void? {
            productosDaos.insertProducto(productos[0])
            return null
        }
    }

    private class UpdateProductoAsyncTask(private val productosDaos: ProductosDaos) :
        AsyncTask<ProductoEntity, Void?, Void?>(){
        override fun doInBackground(vararg productos: ProductoEntity): Void? {
            productosDaos.updateProducto(productos[0])
            return null
        }
    }

    private class DeleteProductoAsyncTask(private val productosDaos: ProductosDaos) :
        AsyncTask<ProductoEntity, Void?, Void?>(){
        override fun doInBackground(vararg productos: ProductoEntity): Void? {
            productosDaos.deleteProducto(productos[0])
            return null
        }
    }
}