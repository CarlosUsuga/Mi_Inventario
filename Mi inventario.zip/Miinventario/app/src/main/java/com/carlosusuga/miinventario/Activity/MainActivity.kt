package com.carlosusuga.miinventario.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.carlosusuga.miinventario.Entities.ProductoEntity
import com.carlosusuga.miinventario.ListAdapters.ProductoAdapter
import com.carlosusuga.miinventario.R
import com.carlosusuga.miinventario.ViewModel.ProductoViewModel
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private var productoViewModel: ProductoViewModel? = null
    val adapter = ProductoAdapter()
    var toolbar: MaterialToolbar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        toolbar?.setTitle(R.string.app_name)
        setSupportActionBar(toolbar)

        val btnAddProducto = findViewById<FloatingActionButton>(R.id.button_add_producto)
        btnAddProducto.setOnClickListener {
            val intent = Intent( this@MainActivity, AddProducto::class.java)
            startActivityForResult(intent, ADD_PRODUCT_REQUEST)
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        productoViewModel = ViewModelProvider(this@MainActivity).get(ProductoViewModel::class.java)
        productoViewModel!!.allProductos.observe(this){ productos ->
            //Actualizar recyclerview
            adapter.submitList(productos)
        }

        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            0,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                productoViewModel!!.deteleProducto(adapter.getProductAt(viewHolder.adapterPosition)!!)
                Toast.makeText(this@MainActivity, "Producto Eliminado", Toast.LENGTH_LONG).show()
            }
        }).attachToRecyclerView(recyclerView)

        adapter.setOnItemClickListener { productoEntity: ProductoEntity ->
            val intent = Intent(this@MainActivity, AddProducto::class.java)
            intent.putExtra(AddProducto.EXTRA_ID, productoEntity.id)
            intent.putExtra(AddProducto.EXTRA_NAME_PRODUCTO, productoEntity.nombreProducto)
            intent.putExtra(AddProducto.EXTRA_PRECIO, productoEntity.precio)
            intent.putExtra(AddProducto.EXTRA_DESCUENTO, productoEntity.descuento)
            intent.putExtra(AddProducto.EXTRA_CATEGORIA, productoEntity.categoria)
            intent.putExtra(AddProducto.EXTRA_RATING, productoEntity.rating)
            intent.putExtra(AddProducto.EXTRA_STOCK, productoEntity.stock)
            intent.putExtra(AddProducto.EXTRA_MARCA, productoEntity.marca)
            startActivityForResult(intent, EDIT_PRODUCTO_REQUEST)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ADD_PRODUCT_REQUEST && resultCode == RESULT_OK){

            val id = data!!.getIntExtra(AddProducto.EXTRA_ID, 0)
            val nombreProducto = data.getStringExtra(AddProducto.EXTRA_NAME_PRODUCTO)
            val precio = data.getIntExtra(AddProducto.EXTRA_PRECIO, 0)
            val descuento = data.getIntExtra(AddProducto.EXTRA_DESCUENTO, 0)
            val categoria = data.getStringExtra(AddProducto.EXTRA_CATEGORIA)
            val rating = data.getIntExtra(AddProducto.EXTRA_RATING, 0)
            val stock = data.getIntExtra(AddProducto.EXTRA_STOCK, 0)
            val marca = data.getStringExtra(AddProducto.EXTRA_MARCA)

            val producto = ProductoEntity(id, nombreProducto.toString(), precio, descuento, categoria.toString(), rating, stock, marca.toString())

            productoViewModel!!.insertProducto(producto)
            Toast.makeText(this, "Producto Guardado", Toast.LENGTH_LONG).show()

        } else if (requestCode == EDIT_PRODUCTO_REQUEST && resultCode == RESULT_OK) {
            val id = data!!.getIntExtra(AddProducto.EXTRA_ID, -1)

            if (id == -1){
                Toast.makeText(this, "NO se puede actualizar datos", Toast.LENGTH_LONG).show()
                return
            }

            val nombreProducto = data.getStringExtra(AddProducto.EXTRA_NAME_PRODUCTO)
            val precio = data.getIntExtra(AddProducto.EXTRA_PRECIO, 0)
            val descuento = data.getIntExtra(AddProducto.EXTRA_DESCUENTO, 0)
            val categoria = data.getStringExtra(AddProducto.EXTRA_CATEGORIA)
            val rating = data.getIntExtra(AddProducto.EXTRA_RATING, 0)
            val stock = data.getIntExtra(AddProducto.EXTRA_STOCK, 0)
            val marca = data.getStringExtra(AddProducto.EXTRA_MARCA)

            val producto = ProductoEntity(id, nombreProducto.toString(), precio, descuento, categoria.toString(), rating, stock, marca.toString())
            producto.id = id

            productoViewModel!!.updateProducto(producto)

            Toast.makeText(this, "Producto Actualizado", Toast.LENGTH_LONG).show()

        } else {
            Toast.makeText(this, " No  se pudo guardar datos", Toast.LENGTH_LONG).show()
        }
    }

    companion object{
        const val ADD_PRODUCT_REQUEST = 1
        const val EDIT_PRODUCTO_REQUEST = 2
    }
}