package com.carlosusuga.miinventario.DataBase

import android.content.Context
import android.os.AsyncTask
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.carlosusuga.miinventario.DaosInterface.ProductosDaos
import com.carlosusuga.miinventario.Entities.ProductoEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(entities = [ProductoEntity::class], version = 1, exportSchema = false)
abstract class MiInventarioDataBase : RoomDatabase(){

    abstract fun productosDaos(): ProductosDaos

    private class PopulateDbAsyncTask(db: MiInventarioDataBase?) : AsyncTask<Void, Void, Void>(){
        private val productosDaos: ProductosDaos
        override fun doInBackground(vararg voids: Void?): Void? {
            productosDaos.insertProducto(ProductoEntity(1, "pikachu", 333, 222, "pokemon", 2, 2, "pokemon"))
            return null
        }

        init {
            productosDaos =  db!!.productosDaos()
        }
    }


    companion object {
        private var instance: MiInventarioDataBase? = null
        @JvmStatic
        @Synchronized
        fun getInstance(context: Context /*scope: CoroutineScope*/): MiInventarioDataBase? {
            if (instance == null) {
                instance = Room.databaseBuilder(
                    context.applicationContext,
                    MiInventarioDataBase::class.java, "inventario_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build()
            }
            return instance
        }

        private val roomCallback: Callback = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                PopulateDbAsyncTask(instance).execute()
            }
        }
    }
}