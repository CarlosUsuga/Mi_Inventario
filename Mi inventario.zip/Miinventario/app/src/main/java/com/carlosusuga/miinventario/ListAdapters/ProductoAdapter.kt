package com.carlosusuga.miinventario.ListAdapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.carlosusuga.miinventario.Entities.ProductoEntity
import com.carlosusuga.miinventario.R
import com.carlosusuga.miinventario.ListAdapters.ProductoAdapter.ProductHolder

class ProductoAdapter : ListAdapter<ProductoEntity, ProductHolder> (DIFF_CALLBACK) {

    private var listener: OnItemClickListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_producto, parent, false)
        return ProductHolder(itemView)
    }

    override fun onBindViewHolder(holder: ProductHolder, position: Int) {
        val currentProducto = getItem(position)
        holder.tvNombreProducto.text = currentProducto!!.nombreProducto
        holder.tvPrecio.text = currentProducto.precio.toString()
        holder.tvDescuento.text = currentProducto.descuento.toString()
        holder.tvRating.text = currentProducto.rating.toString()
        holder.tvCategoria.text = currentProducto.categoria
        holder.tvMarca.text = currentProducto.marca
        holder.tvStock.text = currentProducto.stock.toString()
    }

    fun getProductAt(position: Int) : ProductoEntity? {
        return getItem(position)
    }

    inner class ProductHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val tvNombreProducto: TextView
        val tvPrecio: TextView
        val tvDescuento: TextView
        val tvRating: TextView
        val tvCategoria: TextView
        val tvMarca: TextView
        val tvStock: TextView

        init {
            tvNombreProducto = itemView.findViewById(R.id.tvNameProduct)
            tvPrecio = itemView.findViewById(R.id.tvPrice)
            tvDescuento = itemView.findViewById(R.id.tvDesc)
            tvRating = itemView.findViewById(R.id.tvRatingg)
            tvCategoria = itemView.findViewById(R.id.tvCategory)
            tvMarca = itemView.findViewById(R.id.tvMarc)
            tvStock = itemView.findViewById(R.id.tvStocks)
            itemView.setOnClickListener {
                val position = adapterPosition
                if (listener != null && position != RecyclerView.NO_POSITION){
                    listener!!.onItemClick(getItem(position))
                }
            }
        }
    }

    interface OnItemClickListener{
        fun onItemClick(productoEntity: ProductoEntity)
    }

    fun setOnItemClickListener(listener: (ProductoEntity) -> Unit){
        listener
    }

    companion object{
        private val DIFF_CALLBACK: DiffUtil.ItemCallback<ProductoEntity> =
            object : DiffUtil.ItemCallback<ProductoEntity>(){
                override fun areItemsTheSame(
                    oldItem: ProductoEntity,
                    newItem: ProductoEntity
                ): Boolean {
                    return oldItem.id == newItem.id
                }

                override fun areContentsTheSame(
                    oldItem: ProductoEntity,
                    newItem: ProductoEntity
                ): Boolean {
                    return oldItem.nombreProducto == newItem.nombreProducto &&
                            oldItem.precio == newItem.precio &&
                            oldItem.descuento == newItem.descuento &&
                            oldItem.rating == newItem.rating &&
                            oldItem.categoria == newItem.categoria &&
                            oldItem.marca == newItem.marca &&
                            oldItem.stock == newItem.stock
                }

            }
    }
}