package com.carlosusuga.miinventario.DaosInterface

import androidx.lifecycle.LiveData
import androidx.room.*
import com.carlosusuga.miinventario.Entities.ProductoEntity

@Dao
interface ProductosDaos {
    @Insert
    fun insertProducto(productoEntity: ProductoEntity)

    @Update
    fun updateProducto(productoEntity: ProductoEntity)

    @Delete
    fun deleteProducto(productoEntity: ProductoEntity)

    @Query("SELECT * FROM producto_table ORDER BY nombreProducto ASC")
    fun allProductos(): LiveData<List<ProductoEntity>>
}