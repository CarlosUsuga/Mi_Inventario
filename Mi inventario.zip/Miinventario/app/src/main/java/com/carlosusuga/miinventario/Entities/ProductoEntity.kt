package com.carlosusuga.miinventario.Entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "producto_table")
data class ProductoEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int,

    @ColumnInfo(name = "nombreProducto")
    var nombreProducto: String,

    @ColumnInfo(name = "precio")
    var precio: Int,

    @ColumnInfo(name = "descuento")
    var descuento: Int,

    @ColumnInfo(name = "categoria")
    var categoria: String,

    @ColumnInfo(name = "rating")
    var rating: Int,

    @ColumnInfo(name = "stock")
    var stock:Int,

    @ColumnInfo(name = "marca")
    var marca: String

)